#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include "pt61_sem.h"

// Implementation of the dining philosopher's problem
// We'll set this up so that the philosophers are numbered 0-(N-1) and a philosopher, Pi,
// has a fork on the left numbered i and a fork on the right numbered (i+1) mod N 

#define NPhilosophers 5
#define RANDOM_INT(lo, hi) ((int)(lo + ((double)random() / RAND_MAX) * (hi - lo + 1)))

void *
philosopher(void *arg)
{
    int id;

    id = (int)(arg);
    printf("Philosopher %d starting up\n", id);

    while (1) {
        // We simulate both thinking and eating with Sleeping
	printf("Philosopher %d is thinking\n", id);
        usleep(RANDOM_INT(10, 100));

	printf("Philosopher %d is eating\n", id);
        usleep(RANDOM_INT(10, 100));
    }
}

int
main(void)
{
    pthread_t ids[NPhilosophers];
    pthread_mutex_t main_mutex;
    pthread_cond_t main_cv;
    struct timeval tv;
    struct timespec ts;

    // Create mutex and CV on which we'll block
    if (pthread_mutex_init(&main_mutex, NULL) != 0) {
        fprintf(stderr, "Philosophers: Mutex init failed %s\n", strerror(errno));
        exit(1);
    }
    if (pthread_cond_init(&main_cv, NULL) != 0) {
        fprintf(stderr, "Philosophers: CV init failed %s\n", strerror(errno));
        exit(1);
    }

    // Spawn philosopher threads
    for (long long i = 0; i < NPhilosophers; i++) {
        if (pthread_create(ids + i, NULL, philosopher, (void *)i) != 0) {
	    fprintf(stderr, "Philosophers: Thread create failed %s\n",
	        strerror(errno));
	    exit (1);
	}
    }

    // We'll do a timed wait and then kill all the philosophers (how brutal)
    gettimeofday(&tv, NULL);
    ts.tv_nsec = 0;
    ts.tv_sec = tv.tv_sec + 1;
    if (pthread_cond_timedwait(&main_cv, &main_mutex, &ts) != 0)
        fprintf(stderr, "Philosophers: Timed wait error %s\n", strerror(errno));

    // Be tidy -- kill philosophers
    for (long long i = 0; i < NPhilosophers; i++)
        pthread_kill(ids[i], SIGINT);

    exit(1);
}
