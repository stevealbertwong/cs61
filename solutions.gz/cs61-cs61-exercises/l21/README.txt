These exercises are more synchronization!

Hardly anyone got to dobby with semaphores in l20, so we'll start with that.
Then we'll try the dining philosopher's problem.

