#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include "bits.h"

/*
 * Test out the bit library. We'll have a little interactive loop
 * that implements the following usage.
 */
void
usage(void)
{
    printf("Valid commands are:  \n");
    printf("\te Exit\n");
    printf("\tg <pte> Return page number\n");
    printf("\tm <pgno> <access> <priv> makes PTE\n");
    printf("\to <VA> <pagesize> Returns page offset of VA\n");
    printf("\tp <VA> <pagesize> Returns page number of VA\n");
    printf("\tr <pte> Is PTE readable\n");
    printf("\tt <num> Is power of two\n");
    printf("\tv <pte> Is PTE for privileged access\n");
    printf("\tw <pte> Is PTE writable\n");
    printf("\tx <pte> Is PTE executable\n");
}


int
main(int argc, char *argv[])
{
    char cmd;
    uintptr_t va;
    unsigned long access, pagesize, pgno, priv, pte;

    while (1) {
        printf("> ");
        do {
            scanf("%c", &cmd);
        } while (cmd == '\n');

        switch(cmd) {
            case 'e': // exit
                return (0);
	    case 'g': // Return physical page number from a pte
		scanf("%lx", &pte);
		printf("%x\n", pte_to_pagenum(pte));
	    	break;
	    case 'm': // Make PTE
	    	scanf("%lu %lu %lu", &pgno, &access, &priv);
		printf("%x\n", make_pte(pgno, access, priv));
		break;
	    case 'o': // Page offset of
	    	scanf("%x %lu", &va, &pagesize);
		printf("%u\n", va_to_page_offset(va, pagesize));
	    	break;
            case 'p': // Page number of
	    	scanf("%x %lu", &va, &pagesize);
		printf("%u\n", va_to_page_number(va, pagesize));
                break;
	    case 'r': // Is PTE readable?
	    	scanf("%lx", &pte);
		printf("%s\n", pte_is_readable(pte) ? "yes" : "no");
		break;
	    case 't':
	    	scanf("%lu", &pagesize);
		printf("%s\n", is_power_of_two(pagesize) ? "yes" : "no");
	    	break;
	    case 'v': // Is PTE privileged
	    	scanf("%lx", &pte);
		printf("%s\n", pte_is_privileged(pte) ? "yes" : "no");
		break;
	    case 'w': // Is PTE writable
	    	scanf("%lx", &pte);
		printf("%s\n", pte_is_writeable(pte) ? "yes" : "no");
		break;
	    case 'x': // Is PTE executable
	    	scanf("%lx", &pte);
		printf("%s\n", pte_is_executable(pte) ? "yes" : "no");
		break;
            default:
                usage();
                break;
        }
    }
}
