// Practice manipulating bits in the service of accessing parts of
// virtual memory structures.
//
// In the video we saw a collection of macros that we'll use when we
// implement parts of Weensy OS. For now, let's write some routines
// that extract fields from virtual addresses and page table entries,
// given the sizes of those fields.  This will both provide experience
// manipulating virtual addresses as well as reinforce all those pesky
// bit manipulation mechanisms in C.
#include <assert.h>
#include <stdio.h>
#include "bits.h"

// Determine if a value is a power of 2
int
is_power_of_two(unsigned val)
{
	return (0);
}

// Assuming that val is a power of 2, figure out
// how many bits you have to shift for it.
int
bit_shift(unsigned val)
{
	return (0);
}

// Given a virtual address and page size, return the page offset
unsigned
va_to_page_offset(uintptr_t va, unsigned pagesize)
{
	return (0);
}
// Given a virtual address and page size, return the page number
unsigned
va_to_page_number(uintptr_t va, unsigned pagesize)
{
	return (0);
}


// Return 1 if the PTE describes an entry that specified privileged access
unsigned
pte_is_privileged(unsigned pte)
{
	return (0);
}

// Return 1 if the PTE describes an entry that specified readable access
unsigned
pte_is_readable(unsigned pte)
{
	return (0);
}

// Return 1 if the PTE describes an entry that specified writable access
unsigned
pte_is_writeable(unsigned pte)
{
	return (0);
}

// Return 1 if the PTE describes an entry that specified readable access
unsigned
pte_is_executable(unsigned pte)
{
	return (0);
}

// Return page number from PTE
unsigned
pte_to_pagenum(unsigned pte)
{
	return (0);
}


// GIven a physical page number, 3 bits of access mode and 1 bit of privilege,
// return a PTE
unsigned
make_pte(unsigned pgno, unsigned access, unsigned priv)
{
	return (0);
}

