#include <stdint.h>
// Routines to extract parts of a virtual address
int is_power_of_two(unsigned val);
unsigned va_to_page_offset(uintptr_t va, unsigned pagesize);
unsigned va_to_page_number(uintptr_t va, unsigned pagesize);

// Routines to manipulate page table entries
// We assume that the PTE is organized as follows:
//	bit 0 is the privileged bit (0 = unprivileged; 1 = privileged)
//	bits 1, 2, and 3 indicate rwx permissions respectively
//	The remaining bits are the page number

unsigned pte_is_privileged(unsigned pte);
unsigned pte_is_readable(unsigned pte);
unsigned pte_is_writeable(unsigned pte);
unsigned pte_is_executable(unsigned pte);
unsigned pte_to_pagenum(unsigned pte);
unsigned make_pte(unsigned pgno, unsigned access, unsigned priv);

