#ifndef MATRIXINCLUDES_H
#define MATRIXINCLUDES_H 1

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <limits.h>
#include <stdint.h>
#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>

#endif
