static int sum;

void
do_something(int val) {
    sum += val;
    return;
}
