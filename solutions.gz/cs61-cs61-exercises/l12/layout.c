#include <stdio.h>
#define ROWS 2
#define COLS 4

int array[ROWS][COLS];

int
main(void)
{
    // Write code here to iterate over every item
    // in the array, printing out each element
}
