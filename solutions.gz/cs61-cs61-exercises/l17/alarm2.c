// Also a somewhat silly program -- also sets an alarm and wakes you up,
// but uses a signal handler to do it.
// Take aways: Make sure you know how to:
//	A. install a signal handler
//	B. handle a signal
//	C. set a timer
#include <sys/time.h>
#include "helpers.h"

#define ALARM 1

void signal_handler(int signal) {
    // Don't really have to do much here.
    (void) signal;
}

int main(void) {
    int r;
    struct itimerval itimer;
    unsigned u;

    fprintf(stderr, "Hello from parent pid %d\n", getpid());

    // Set up a signal handler for the timer signal, SIGALRM
    r = handle_signal(SIGALRM, signal_handler);
    assert(r >= 0);

    // Set alarm ALARM seconds from now
    timerclear(&itimer.it_interval);
    itimer.it_value.tv_sec = 1;
    itimer.it_value.tv_usec = 0;
    r = setitimer(ITIMER_REAL, &itimer, NULL);
    assert(r >= 0);

    // Now, sleep for a long time, so that we get awakened by the
    // signal and not simply by waking up -- we'll check the
    // status of sleep to differentiate the two.
    u = sleep(1000000);

    if (u == 0)
        printf("I feel rested! I slept the whole time!\n");
    else
        printf("I'm sleepy!  I was awakened by an alarm clock!\n");

    return (0);
}
