#include "helpers.h"

// TODO Write a signal handler here that we'll use to handle the signal
// generated when a child exits

int main(void) {
    double start_time;
    int ret;
    pid_t p1;

    fprintf(stderr, "Hello from parent pid %d\n", getpid());

    // TODO Register a signal handler that will get called when a child
    // process exits

    // Start a child
    p1 = nfork();
    assert(p1 >= 0);
    if (p1 == 0) {
        usleep(500000);  // microsecond sleep
        fprintf(stderr, "Goodbye from child pid %d\n", getpid());
        exit(0);
    }
    start_time = timestamp();

    // Now let's go to sleep -- if our sleep finishes, then we are saying that
    // the child timed out; if our sleep doesn't finish, it means we got
    // interrupted to the signal from the child.
    ret = usleep(750000);
    if (ret == -1 && errno == EINTR)
        fprintf(stderr, "usleep interrupted by signal after %g sec\n",
                timestamp() - start_time);
    else
        fprintf(stderr, "Child timed out\n");
}
