// This program combines a SIGALRM signal with waiting on a child to try
// to solve the "wait for a child, but no longer than 1 second" problem.

#include "helpers.h"

void signal_handler(int signal) {
    (void) signal;
}

int
main(void) {
    double start_time;
    int ret, status;
    pid_t exited_pid, p1;
    struct itimerval itimer;

    fprintf(stderr, "Hello from parent pid %d\n", getpid());

    // Let's start a child process
    p1 = nfork();
    assert(p1 >= 0);
    if (p1 == 0) {
    	// We are in the child.
        sleep(1);
        fprintf(stderr, "Goodbye from child pid %d\n", getpid());
        exit(0);
    }
    start_time = timestamp();

    // Handle SIGALRM; no action is required
    ret = handle_signal(SIGALRM, signal_handler);
    assert(ret >= 0);

    // Set alarm for 0.75 seconds
    timerclear(&itimer.it_interval);
    itimer.it_value.tv_sec = 0;
    itimer.it_value.tv_usec = 750000;
    ret = setitimer(ITIMER_REAL, &itimer, NULL);
    assert(ret >= 0);

    // Wait for the child and print its status
    exited_pid = waitpid(p1, &status, 0);

    // We should only get here under two conditions:
    // 1. The child existed (exited_pid == p1), or
    // 2. Our waitpid call was interrupted
    //
    assert(exited_pid == p1 || (exited_pid == -1 && errno == EINTR));

    if (exited_pid == -1)
        fprintf(stderr, "Child timed out\n");
    else if (WIFEXITED(status))
        fprintf(stderr, "Child exited with status %d after %g sec\n",
                WEXITSTATUS(status), timestamp() - start_time);
    else
        fprintf(stderr, "Child exited abnormally [%x]\n", status);

    return (0);
}
