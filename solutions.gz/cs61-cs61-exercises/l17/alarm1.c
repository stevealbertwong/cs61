#include <stdio.h>
#include <unistd.h>
#define ALARM 1

// Ridiculously silly program to implement an alarm clock -- basically we
// sleep and then wake up and print a message.
int
main(void) {
    fprintf(stderr, "Hello from parent pid %d\n", getpid());
    sleep(ALARM);
    printf("\a\a\aWake up!\n");
}
