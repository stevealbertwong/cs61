These exercises are more synchronization!

Hardly anyone got to dobby in l19, so we'll start with that. Then we'll try
dobby with semaphores, which is an interesting problem, because it seems
like a counting semaphore should work, but if you have to individually
acknowledge each elf, it's problematic.
