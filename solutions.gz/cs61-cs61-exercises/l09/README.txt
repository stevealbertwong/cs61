Beginning of cache exercises. It's possible that some of the performance
differences illustrated here will not be apparent int he appliance, so
you may need/want to run them directly on your laptop/desktop. They are
relatively simple programs that should translate easily.
