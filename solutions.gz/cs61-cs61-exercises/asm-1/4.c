//! -O1
extern int a;
extern int b;
int
sub(void)
{
    return (a - b);
}
