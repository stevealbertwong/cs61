//! -O1
extern long a;
extern long b;
long
div(void)
{
    return (a / b);
}
