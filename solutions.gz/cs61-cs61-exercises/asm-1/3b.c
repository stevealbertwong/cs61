//! -O1
extern char *a;
extern long b;
char *
sum(void)
{
    return (a + b);
}
