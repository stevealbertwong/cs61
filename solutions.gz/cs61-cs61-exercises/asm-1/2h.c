//! -O1
extern char a;
extern char b;
char
sum(void)
{
    return (a + b);
}
