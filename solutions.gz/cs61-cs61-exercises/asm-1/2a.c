extern unsigned a;
extern unsigned b;
//! -O1
unsigned
sum(void)
{
    return (a + b);
}
