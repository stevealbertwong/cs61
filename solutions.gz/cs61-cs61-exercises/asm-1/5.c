//! -O1
extern int a;
extern int b;
int
mul(void)
{
    return (a * b);
}
