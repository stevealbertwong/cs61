//! -O1
extern int a;
extern unsigned b;
int
sum(void)
{
    return (a + b);
}
