void
func(int a)
{
    a = a;
    return;
}
