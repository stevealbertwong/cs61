//! -O1
extern long long a;
extern long b;
long
sum(void)
{
    return ((a & 0xFFFFFFFF) + b);
}
