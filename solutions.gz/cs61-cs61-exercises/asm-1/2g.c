//! -O1
extern short a;
extern short b;
short
sum(void)
{
    return (a + b);
}
