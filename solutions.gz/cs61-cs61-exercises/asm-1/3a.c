//! -O1
extern long long a;
extern long long b;
long long
sum(void)
{
    return (a + b);
}
