//! -O1
extern int a;
extern int b;
int
sum(void)
{
    return (a + b);
}
