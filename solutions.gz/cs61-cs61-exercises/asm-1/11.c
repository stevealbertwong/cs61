#include <stdio.h>

void
swap(int *ap, int *bp)
{
	int tmp;

	tmp = *ap;
	*ap = *bp;
	*bp = tmp;
}

int
main(void)
{
	int a, b;

	while (1) {
		// This is not a good example of safe user input!
		printf("Enter A: ");
		if (scanf("%d", &a) != 1)
			break;
		printf("Enter B: ");
		if (scanf("%d", &b) != 1)
			break;
		swap(&a, &b);
		printf("A = %d B = %d\n", a, b);
	}

	return 0;
}
