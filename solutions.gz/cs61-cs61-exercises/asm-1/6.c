//! -O1
extern int a;
extern int b;
int
div(void)
{
    return (a / b);
}
