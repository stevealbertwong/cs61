int
func(int a)
{
    return(a);
}
