//! -O1
extern int a[];
extern unsigned b;
unsigned
sum(void)
{
    return (a[0] + b);
}
