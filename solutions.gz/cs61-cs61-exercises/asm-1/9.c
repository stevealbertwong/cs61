//! -O1
extern unsigned a;
extern unsigned b;
unsigned
or(void)
{
        return (a | b);
}
