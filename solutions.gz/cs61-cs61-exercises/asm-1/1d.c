long
func(long a)
{
    return(a);
}
