//! -O1
extern short a;
extern short b;
short
sub(void)
{
    return (a - b);
}
