#include <stdlib.h>
extern void *a;
extern size_t b;
void *
sum(void)
{
    return (a + b);
}
