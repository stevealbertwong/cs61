int
func(void)
{
    return (0);
}
