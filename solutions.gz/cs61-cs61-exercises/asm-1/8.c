//! -O1
extern unsigned a;
extern unsigned b;
unsigned
and(void)
{
        return (a & b);
}
