//! -O1
void
func(void)
{
    return;
}
