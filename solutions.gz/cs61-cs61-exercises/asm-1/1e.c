long long
func(long long a)
{
    return(a);
}
