CHANGED
#include "cache.h"

// In-class exercise to build a simple read cache capable
// of handling sequential byte accesses
//
// We will make the function prototype of cache_file_open and cache_byte_read
// match open and read so that you can switch to your own cache with minimal
// code modifications.

int
cache_file_open(const char *path, int oflag)
{
    return 0;
}


int
cache_file_read(int fd, void *buf, size_t nbytes)
{
    return 0;
}
