CHANGED
#include "iobench.h"

int cache_file_open(const char *, int);
int cache_file_read(int, void *, size_t);
