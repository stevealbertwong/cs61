#include <stdlib.h>
#include <stdio.h>

int main() {
    // This magic instructs a Linux kernel to flush its buffer cache.
    // See, for example, http://www.kernel.org/doc/Documentation/sysctl/vm.txt

    // flush dirty blocks
    system("/bin/sync");

    // drop clean caches
    FILE* f = fopen("/proc/sys/vm/drop_caches", "w");
    if (f) {
        fprintf(f, "3\n");
        fclose(f);
    } else {
        perror("/proc/sys/vm/drop_caches");
        exit(1);
    }
}
