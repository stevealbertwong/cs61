#include "helpers.h"

int main(void) {
    pid_t root_pid = getpid();
    printf("Hello from root pid %d\n", root_pid);

    pid_t p1 = fork();
    assert(p1 >= 0);

    pid_t p2 = fork();
    assert(p2 >= 0);

    if (getpid() != root_pid)
        printf("Hello from child pid %d\n", getpid());
}
