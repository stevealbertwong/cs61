These code samples go along with the paper and pen exercises we did in
class 1.

fib.c:	A fibonacci program with both iterative and recursive versions.
	fib -a N: Compute fibonacci of N recursively (default)
	fib -b N: Compute fibonacci of N iteratively

hello.c:	The hello world program.

limit.c:	Code for limiting the stack size (extracted from
		lectures/l01/allowexec.c
