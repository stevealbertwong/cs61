void check_system_call(int, const char *);
void limit_stack_size(size_t);
