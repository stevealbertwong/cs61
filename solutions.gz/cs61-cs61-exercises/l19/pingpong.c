// These examples build on/mimic the multi-process ping pong program from
// lecture 18 and the select video. The challenge this time is to synchronize
// two pthreads who need to alternate printing out pings and pongs to the console.
//
// The main program creates two threads, each of whom uses the same function,
// but with a different argument. The argument indicates whether the thread
// is allowed to print on odd or even instances of a global variable. We'll
// start with an unsynchronized version and then try a variety of different
// approaches to synchronizing.

#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// How many total pings and pongs we'll print
#define TOTAL_MSGS 50

// Structure that we'll use to transmit information
// to the threads.

struct pp_thread_info {
    int *msgcount;      // Keeps track of total number of messages; shared state
    char *msg;
    int modval;
};

// Unsynchronized version -- pings and pongs will not alternate nicely

// Thread function for both pings and pongs; the arg function will be 
// pointer to a struct pp_thread_info and carries all the information
// that the thread needs to process pings and pongs.

void *
pp_thread(void *arg)
{
    struct pp_thread_info *infop;

    infop = arg;
    while (*infop->msgcount < TOTAL_MSGS) {
        if (*infop->msgcount % 2 == infop->modval) {
            printf("%s\n", infop->msg);
            (*infop->msgcount)++;
        }
    }

    return (NULL);
}

int
main(void)
{
    pthread_t ping_id, pong_id;
    struct pp_thread_info ping, pong;
    int msgcount;

    msgcount = 0;

    ping.msgcount = &msgcount;
    ping.msg = "ping";
    ping.modval = 0;

    pong.msgcount = &msgcount;
    pong.msg = "pong";
    pong.modval = 1;

    // Create the two threads
    if ((pthread_create(&ping_id, NULL, &pp_thread, &ping) != 0) ||
        (pthread_create(&pong_id, NULL, &pp_thread, &pong) != 0)) {
        fprintf(stderr, "pingpong: pthread_create failed %s\n", strerror(errno));
        exit(1);
    }

    // Now wait for threads to exit (Probably should check for errors)
    pthread_join(ping_id, NULL);
    pthread_join(pong_id, NULL);

    printf("Main thread exiting\n");
}

