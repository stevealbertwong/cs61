pingpong:   Unsynchronized version of pingpong pthread program with only 1 thread of
    each type.
pingpong2: Add multiple threads of each kind and insert a sleep during the increment
    to exhibit the race condition.  Synchronize this three ways: 1) Using a mutex,
    2) using a CV, 3) using multiple CVs.
dobby.c: A synchronization problem making dobby wait on a collection of elf threads.

check.awk -- awk script to detect if your ping pong output is correct.
