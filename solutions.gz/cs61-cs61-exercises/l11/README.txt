We extended the baby cache implementation (l10) into two days.
