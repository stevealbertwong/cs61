There was no code for today, but the examples used in Assembly Roulette
can be found here:
https://drive.google.com/drive/u/1/folders/0B5IVsl3FbyKeZ2dHNFFVUXl6Um8?ths=true

