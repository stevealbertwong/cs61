#include "kernel.h"
#include "lib.h"

// kernel.c
//
//    This is the kernel.


// kernel
//    Initialize the hardware and processes and start running.

void kernel(void) {
    hardware_init();
    console_clear();

    console_printf(CPOS(0, 0), 0xC000, "Hello, world, I am a simple OS\n");
    console_printf(CPOS(1, 0), 0xF000, "Time to do nothing forever\n");
    while (1)
        /* do nothing */;
}


// exception(reg)
//    Exception handler (for interrupts, traps, and faults).
//
//    The register values from exception time are stored in `reg`.
//    The processor responds to an exception by saving application state on
//    the kernel's stack, then jumping to kernel assembly code (in
//    k-exception.S). That code saves more registers on the kernel's stack,
//    then calls exception().
//
//    Note that hardware interrupts are disabled whenever the kernel is running.

void exception(x86_registers* reg) {
    // Show the current cursor location.
    console_show_cursor(cursorpos);

    // If Control-C was typed, exit the virtual machine.
    check_keyboard();


    // Actually handle the exception.
    switch (reg->reg_intno) {

    default:
        panic("Unexpected interrupt %d!\n", reg->reg_intno);
        break;

    }
}
