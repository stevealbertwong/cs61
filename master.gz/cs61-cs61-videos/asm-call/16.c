//! -O1

extern void g(void);

void f(void) {
    g();
}
