//! -O0

extern int sum(int a, int b);

int f(int a, int b) {
    return sum(a, b);
}
