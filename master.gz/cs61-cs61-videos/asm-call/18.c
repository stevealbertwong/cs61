#include <stdio.h>

void f(void) {
    puts("Hello!");
    puts("I love you.");
    puts("This message is false.");
}

int main(void) {
    f();
}
