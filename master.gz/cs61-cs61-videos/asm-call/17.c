extern void g(void);

void f(void) {
    g();
    g();
    g();
}
