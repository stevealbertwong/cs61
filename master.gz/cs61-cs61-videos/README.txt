These directories are named for the Office Mix videos to which they
correspond. Each contains any code used in the videos.
