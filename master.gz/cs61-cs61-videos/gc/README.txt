testgc.c

    A program for investigating conservative garbage collectors.
    Goes with `gc61.c`.
