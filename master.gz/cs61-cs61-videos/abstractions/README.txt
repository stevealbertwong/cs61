infinite.c:	An infinite loop (used to demonstrate process isolation)
hello.c:	Standard hello world program

mexplore.c:	Memory explorer -- copied from cs61-lectures/l02
hexdump.c:	(part of above)
