int
not(int a)
{
    return (~a);
}
