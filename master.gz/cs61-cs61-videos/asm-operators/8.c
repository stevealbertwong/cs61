int
xor(int a, int b)
{
    return (a ^ b);
}
