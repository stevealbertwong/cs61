unsigned
shift(unsigned a, unsigned b)
{
        return (a << b);
}
