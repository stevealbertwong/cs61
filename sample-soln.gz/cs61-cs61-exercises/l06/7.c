unsigned
mul4(unsigned a)
{
        return (a * 4);
}
