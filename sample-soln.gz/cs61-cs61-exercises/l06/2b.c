#include <stdlib.h>
void *
sum(void *a, size_t b)
{
    return (a + b);
}
