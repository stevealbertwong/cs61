unsigned
div4(unsigned a)
{
        return (a / 4);
}
