void
func(int a)
{
    return;
}
