char *
sum(char *a, int b)
{
    return (&a[b]);
}
