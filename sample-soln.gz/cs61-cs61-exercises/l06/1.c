void
func(void)
{
    return;
}
