unsigned
sum(unsigned a, unsigned b)
{
    return (a + b);
}
