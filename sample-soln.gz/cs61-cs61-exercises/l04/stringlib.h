char *string_cat(char *, char *);
int string_cmp(char *, char *);
char *string_dup(char *);
void string_free(char *);
char *string_new(char *);
void string_print(char *);
