
void qs(int* array, int n);

int* qs(const int* array, int n);
