#include <stddef.h>

void allow_execute(const void* ptr, size_t size);
void limit_stack_size(size_t size);
int strisnumber(const char* s);
